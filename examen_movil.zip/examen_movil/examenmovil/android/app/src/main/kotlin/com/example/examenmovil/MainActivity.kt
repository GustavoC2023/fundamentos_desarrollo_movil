package com.example.examenmovil

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
