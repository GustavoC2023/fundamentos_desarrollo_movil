import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Reserva de Viaje',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF007A5E),
        ),
      ),
      home: const MyHomePage(title: 'Reserva de Viaje'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final TextEditingController nombreController = TextEditingController();
  final TextEditingController correoController = TextEditingController();

  String destinoSeleccionado = '';
  String transporteSeleccionado = 'Avion';

  bool hotelIncluido = false;
  bool tourGuiado = false;
  bool seguroViaje = false;
  bool notificaciones = false;

  double presupuesto = 500;

  DateTime? fechaViaje;

  void limpiarFormulario() {
    setState(() {
      nombreController.clear();
      correoController.clear();
      destinoSeleccionado = '';
      transporteSeleccionado = 'Avion';
      hotelIncluido = false;
      tourGuiado = false;
      seguroViaje = false;
      notificaciones = false;
      presupuesto = 500;
      fechaViaje = null;
    });
  }

  void mostrarSnackBar(String mensaje) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mensaje)),
    );
  }

  void mostrarFaltanDatos() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: const [
            Icon(Icons.info_outline, color: Colors.orange),
            SizedBox(width: 12),
            Text('Faltan datos'),
          ],
        ),
        content: const Text(
          'Completa nombre, correo válido (@) y selecciona fecha de viaje',
          style: TextStyle(fontSize: 15),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Entendido'),
          ),
        ],
      ),
    );
  }

  String formatearFecha(DateTime fecha) {
    final dia = fecha.day.toString().padLeft(2, '0');
    final mes = fecha.month.toString().padLeft(2, '0');
    final anio = fecha.year.toString();
    return '$dia/$mes/$anio';
  }

  Future<void> seleccionarFecha() async {
    final DateTime? seleccionada = await showDatePicker(
      context: context,
      initialDate: fechaViaje ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );

    if (seleccionada != null) {
      setState(() {
        fechaViaje = seleccionada;
      });
      mostrarSnackBar('Fecha seleccionada: ${formatearFecha(seleccionada)}');
    }
  }

  double calcularTotal() {
    double total = presupuesto;
    if (hotelIncluido) total += 1200;
    if (tourGuiado) total += 600;
    if (seguroViaje) total += 400;
    return total;
  }

  List<String> obtenerExtrasActivos() {
    final extras = <String>[];
    if (hotelIncluido) extras.add('Hotel incluido');
    if (tourGuiado) extras.add('Tour guiado');
    if (seguroViaje) extras.add('Seguro de viaje');
    return extras;
  }

  String primerNombre() {
    final partes = nombreController.text.trim().split(' ');
    return partes.isNotEmpty ? partes.first : '';
  }

  void verResumen() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Resumen de tu reserva'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Nombre: ${nombreController.text.isEmpty ? "(sin llenar)" : nombreController.text}'),
              Text('Correo: ${correoController.text.isEmpty ? "(sin llenar)" : correoController.text}'),
              Text('Destino: ${destinoSeleccionado.isEmpty ? "(sin seleccionar)" : destinoSeleccionado}'),
              Text('Transporte: $transporteSeleccionado'),
              const SizedBox(height: 8),
              Text('Hotel incluido: ${hotelIncluido ? "Sí" : "No"}'),
              Text('Tour guiado: ${tourGuiado ? "Sí" : "No"}'),
              Text('Seguro de viaje: ${seguroViaje ? "Sí" : "No"}'),
              Text('Notificaciones: ${notificaciones ? "Activadas" : "Desactivadas"}'),
              Text('Presupuesto: \$${presupuesto.toStringAsFixed(0)}'),
              Text('Fecha del viaje: ${fechaViaje == null ? "(sin elegir)" : formatearFecha(fechaViaje!)}'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }

  void confirmarReserva() {
    final nombreValido = nombreController.text.trim().isNotEmpty;
    final correoValido = correoController.text.contains('@');
    final fechaValida = fechaViaje != null;

    if (!nombreValido || !correoValido || !fechaValida) {
      mostrarFaltanDatos();
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PantallaBoleto(
          nombre: primerNombre(),
          correo: correoController.text,
          destino: destinoSeleccionado,
          transporte: transporteSeleccionado,
          extras: obtenerExtrasActivos(),
          notificaciones: notificaciones,
          total: calcularTotal(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
        actions: [
          IconButton(
            onPressed: limpiarFormulario,
            icon: const Icon(Icons.cleaning_services, color: Colors.white),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              ///aqui puse la seccion 1 
              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: Colors.grey),
                ),
                child: const Padding(
                  padding: EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Icon(Icons.info, color: Colors.blue),
                      SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Seccion 1 - Informacion general',
                                style: TextStyle(fontWeight: FontWeight.bold)),
                            Text('Completa tu reserva paso a paso'),
                            Text('Llena tus datos, elige destino y confirma tu viaje.'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              //sec 2.
              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: Colors.grey),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.person, color: Colors.green),
                          SizedBox(width: 12),
                          Text('Seccion 2 - Datos del viajero',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: nombreController,
                        decoration: const InputDecoration(
                          labelText: 'Nombre completo',
                          hintText: 'Ej: Ana Garcia',
                          prefixIcon: Icon(Icons.person),
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: correoController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(
                          labelText: 'Correo electronico',
                          hintText: 'Ej: ana@correo.com',
                          prefixIcon: Icon(Icons.email),
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              /////////////////////////sec3////////////////////////
              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: Colors.grey),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.travel_explore, color: Colors.orange),
                          SizedBox(width: 12),
                          Text('Seccion 3 - Destino y transporte',
                              style: TextStyle(
                                  color: Colors.orange,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () {
                                setState(() => destinoSeleccionado = 'Playa');
                                mostrarSnackBar('Destino seleccionado: Playa');
                              },
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: destinoSeleccionado == 'Playa'
                                      ? Colors.blue.shade100
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: Colors.blue),
                                ),
                                child: const Column(
                                  children: [
                                    Icon(Icons.beach_access, color: Colors.blue, size: 35),
                                    SizedBox(height: 5),
                                    Text('Playa'),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: InkWell(
                              onTap: () {
                                setState(() => destinoSeleccionado = 'Ciudad');
                                mostrarSnackBar('Destino seleccionado: Ciudad');
                              },
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: destinoSeleccionado == 'Ciudad'
                                      ? Colors.orange.shade100
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: Colors.orange),
                                ),
                                child: const Column(
                                  children: [
                                    Icon(Icons.location_city, color: Colors.orange, size: 35),
                                    SizedBox(height: 5),
                                    Text('Ciudad'),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: InkWell(
                              onTap: () {
                                setState(() => destinoSeleccionado = 'Montaña');
                                mostrarSnackBar('Destino seleccionado: Montaña');
                              },
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: destinoSeleccionado == 'Montaña'
                                      ? Colors.green.shade100
                                      : Colors.white,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: Colors.green),
                                ),
                                child: const Column(
                                  children: [
                                    Icon(Icons.landscape, color: Colors.green, size: 35),
                                    SizedBox(height: 5),
                                    Text('Montaña'),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        initialValue: transporteSeleccionado,
                        decoration: const InputDecoration(
                          labelText: 'Transporte',
                          border: OutlineInputBorder(),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'Avion', child: Text('Avion')),
                          DropdownMenuItem(value: 'Autobus', child: Text('Autobus')),
                          DropdownMenuItem(value: 'Tren', child: Text('Tren')),
                          DropdownMenuItem(value: 'Barco', child: Text('Barco')),
                        ],
                        onChanged: (String? nuevoTransporte) {
                          setState(() {
                            transporteSeleccionado = nuevoTransporte!;
                          });
                          mostrarSnackBar('Transporte seleccionado: $nuevoTransporte');
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              
              ///sec4//////////////



              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: Colors.grey),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.settings, color: Colors.purple),
                          SizedBox(width: 12),
                          Text('Seccion 4 - Extras y preferencias',
                              style: TextStyle(
                                  color: Colors.purple,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Container(
                        decoration: BoxDecoration(
                          color: hotelIncluido ? Colors.blue.shade50 : Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.blue),
                        ),
                        child: CheckboxListTile(
                          value: hotelIncluido,
                          title: const Text('Hotel incluido (+ \$1200)'),
                          secondary: const Icon(Icons.hotel, color: Colors.blue),
                          onChanged: (v) {
                            setState(() => hotelIncluido = v!);
                            mostrarSnackBar(
                                'Hotel incluido: ${v! ? "Activado" : "Desactivado"}');
                          },
                        ),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        decoration: BoxDecoration(
                          color: tourGuiado ? Colors.orange.shade50 : Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.orange),
                        ),
                        child: CheckboxListTile(
                          value: tourGuiado,
                          title: const Text('Tour guiado (+ \$600)'),
                          secondary: const Icon(Icons.tour, color: Colors.orange),
                          onChanged: (v) {
                            setState(() => tourGuiado = v!);
                            mostrarSnackBar(
                                'Tour guiado: ${v! ? "Activado" : "Desactivado"}');
                          },
                        ),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        decoration: BoxDecoration(
                          color: seguroViaje ? Colors.green.shade50 : Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.green),
                        ),
                        child: CheckboxListTile(
                          value: seguroViaje,
                          title: const Text('Seguro de viaje (+ \$400)'),
                          secondary: const Icon(Icons.health_and_safety, color: Colors.green),
                          onChanged: (v) {
                            setState(() => seguroViaje = v!);
                            mostrarSnackBar(
                                'Seguro de viaje: ${v! ? "Activado" : "Desactivado"}');
                          },
                        ),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        decoration: BoxDecoration(
                          color: notificaciones ? Colors.purple.shade50 : Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.purple),
                        ),
                        child: SwitchListTile(
                          value: notificaciones,
                          title: const Text('Recibir notificaciones'),
                          subtitle: Text(notificaciones ? 'Activadas' : 'Desactivadas'),
                          secondary: const Icon(Icons.notifications, color: Colors.purple),
                          onChanged: (v) {
                            setState(() => notificaciones = v);
                            mostrarSnackBar(
                                'Notificaciones: ${v ? "Activadas" : "Desactivadas"}');
                          },
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text('Presupuesto: \$${presupuesto.toStringAsFixed(0)}',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      Slider(
                        value: presupuesto,
                        min: 500,
                        max: 10000,
                        divisions: 20,
                        label: '\$${presupuesto.toStringAsFixed(0)}',
                        onChanged: (v) {
                          setState(() => presupuesto = v);
                        },
                        onChangeEnd: (v) {
                          mostrarSnackBar('Presupuesto: \$${v.toStringAsFixed(0)}');
                        },
                      ),
                      const SizedBox(height: 16),
                      InkWell(
                        onTap: seleccionarFecha,
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.grey),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.calendar_month, color: Colors.teal),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('Fecha del viaje',
                                        style: TextStyle(fontWeight: FontWeight.bold)),
                                    Text(
                                      fechaViaje == null
                                          ? 'Toca para elegir fecha'
                                          : formatearFecha(fechaViaje!),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              ///////////////sec5
              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: Colors.grey),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.check_circle, color: Colors.teal),
                          SizedBox(width: 12),
                          Text('Seccion 5 - Confirmar',
                              style: TextStyle(
                                  color: Colors.teal,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      const Text('Revisa tus datos antes de despegar'),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: verResumen,
                              icon: const Icon(Icons.list_alt),
                              label: const Text('Ver Resumen'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: confirmarReserva,
                              icon: const Icon(Icons.check),
                              label: const Text('Confirmar'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class PantallaBoleto extends StatelessWidget {
  final String nombre;
  final String correo;
  final String destino;
  final String transporte;
  final List<String> extras;
  final bool notificaciones;
  final double total;

  const PantallaBoleto({
    super.key,
    required this.nombre,
    required this.correo,
    required this.destino,
    required this.transporte,
    required this.extras,
    required this.notificaciones,
    required this.total,
  });
////////////////////////////////////////////////////////SEG. Pantalla//////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('Mi Boleto'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Card(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: const BorderSide(color: Colors.grey),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Text(
                          '¡Buen viaje, $nombre!',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Center(
                        child: Text(
                          destino,
                          style: const TextStyle(
                            fontSize: 18,
                            color: Colors.teal,
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),

                      //////////////////////////////////////////////////////////////
                      SizedBox(
                        width: double.infinity,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.asset(
                            'assets/que-hace-un-licenciado-turismo-1280x720.jpg',
                            height: 200,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      //////////////////////////aqui puse la imagen xd//////////////
                      const SizedBox(height: 30),

                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.email, color: Colors.blue),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Correo',
                                  style: TextStyle(fontSize: 14)),
                              Text(
                                correo,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.location_on, color: Colors.red),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Destino',
                                    style: TextStyle(fontSize: 14)),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      destino,
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Colors.grey.shade200,
                                        borderRadius:
                                            BorderRadius.circular(8),
                                        border:
                                            Border.all(color: Colors.grey),
                                      ),
                                      child: Text(
                                        transporte,
                                        style: const TextStyle(fontSize: 12),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.star, color: Colors.amber),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Extras',
                                    style: TextStyle(fontSize: 14)),
                                Text(
                                  extras.isEmpty
                                      ? 'Ninguno'
                                      : extras.join(', '),
                                  style: const TextStyle(fontSize: 16),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.notifications, color: Colors.purple),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Notificaciones',
                                    style: TextStyle(fontSize: 14)),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      notificaciones
                                          ? 'Activadas'
                                          : 'Desactivadas',
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '\$${total.toStringAsFixed(0)}',
                                      style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.green,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back),
                  label: const Text('Regresar y editar'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}